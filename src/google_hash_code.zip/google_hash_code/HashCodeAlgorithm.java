/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package google_hash_code;

/**
 *
 * @author Miguel Freitas
 * @param <R>
 */
public interface HashCodeAlgorithm {
    
    public  void algorithm(ResultList r);
    
}
